from sys import path_importer_cache
import numpy as np
from math import copysign

from numpy.core.numeric import outer

class carrier_sync:
    def calcloopgains(self, PhRecBW, dampling_factor, sampl_PS):
        phreclg = PhRecBW * sampl_PS

        theta = phreclg/((dampling_factor + 0.25/dampling_factor)*sampl_PS)
        d = 1 +2*dampling_factor*theta + theta*theta
        
        PhErrGain = 1 #For 8-PSK - look at MATLAB comm.CarrierSynchronizer help page

        PhRecGain = sampl_PS
        #K1
        Kp = (4*dampling_factor*theta/d)/(PhErrGain*PhRecGain)

        #K2
        Ki = (4*theta*theta/d)/(PhErrGain*PhRecGain)

        return Ki, Kp

    def stepImpl(self, input ,Ki, Kp):
        inputC = input
        K = 154 #np.sqrt(2) -1
        output = np.zeros(len(inputC)) + 1j*np.zeros(len(inputC))
        phcorr = np.zeros(len(inputC))
        loopFiltState = 0
        IntegFiltState = 0
        DDSPrevInp = 0
        prevSample = 0
        Phase = 0
        errorv = np.zeros(len(inputC))
        for k in range(len(inputC)):
            if np.abs(np.real(prevSample)) >= np.abs(np.imag(prevSample)):
                pherr = K*copysign(1, np.real(prevSample))*np.imag(prevSample)/64 - copysign(1, np.imag(prevSample))*np.real(prevSample)
            else:
                pherr = copysign(1, np.real(prevSample))*np.imag(prevSample) - K*copysign(1, np.imag(prevSample))*np.real(prevSample)/64
    
            output[k] = (np.real(inputC[k])*np.cos(Phase) + np.imag(inputC[k])*np.sin(Phase)) + 1j*(np.imag(inputC[k])*np.cos(Phase) - np.real(inputC[k])*np.sin(Phase))
            
            loopFlltOut = pherr * Ki + loopFiltState
            loopFiltState = loopFlltOut

            DDsOUT = DDSPrevInp + IntegFiltState
            IntegFiltState = DDsOUT
            DDSPrevInp = pherr * Kp + loopFlltOut

            Phase = DDsOUT
            phcorr[k]  = Phase
            prevSample = output[k]
            errorv[k] = pherr
        return output, phcorr, errorv